# This folder contains the curve data for GE E3 Engine Fan geometry

# Each fan curve layer number ranges from 1 at the hub all the way to 20 near the shroud.

# fan_full-part file contains all the curves to import in a CAD program if the need arises to look at the full part.

# Apart from these, there were four extra surface curve layers that have been saved as # fan-surface-curve_layer from 01 to 04